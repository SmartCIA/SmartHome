var Cylon = require('cylon'),
    express = require('express.io'),
    mongoose = require("mongoose"),
    temper = require('./models/temperature.js'),
    ExeStepper = require('./models/stepper.js'),
    control_light = require('./models/lamps.js');
	var bodyParser = require("body-parser");
    app = express();
    var HashMap = require('hashmap');
//var async         = require("async");

//Variable declarations of Microcontroller lamps.
var bathroom = 0;
var connection_lamp_all = 0;
var kitchen = 0;
var room = 0;
var room2 = 0;
var controlAll_lamp = 0;
var bedroom = 0;
var user_name;
var password;
var relaySensorsMap = new HashMap();

app.sensorsReady = false;
app.sensors = {};

app.use(express.static(__dirname + '/public'));
app.http().io();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/',function(req,res){
  res.writeHead(200, {
     'Content-Type': 'text/plain',
     'Access-Control-Allow-Origin': '*' // implementation of CORS
  });
  user_name = req.body.user;
  password = req.body.passwd;
  user_name = 0;
  console.log(user_name);
  app.relay_bathroomController();
  res.end("done");
});


//Add the routes
routes = require('./routes/smartroute.js')(app);
app.io.route('readySensors', function (req) {
  Cylon.robot({
    connections: {
      galileo: {
        adaptor: 'intel-iot'
      }
    },
    devices: {
      temp_bathroom: {driver: 'analogSensor',pin: 0},
      temp_kitchen: {driver: 'analogSensor', pin: 1},
      temp_bedroom: {driver: 'analogSensor', pin: 2},
      temp_room: {driver: 'analogSensor', pin: 3},
      relay_bathroom: {driver: 'direct-pin',pin: 6},
      relay_kitchen: {driver: 'direct-pin',pin: 7},
      relay_room: {driver: 'direct-pin',pin: 8},
      relay_room2: {driver: 'direct-pin',pin: 9},
      relay_bedroom: {driver: 'direct-pin',pin: 10}
    },

	work: function (my) {
	 app.sensorsReady = true;
	 app.sensors = {
	 temp_bathroom: my.temp_bathroom,
	 temp_kitchen: my.temp_kitchen,
	 temp_bedroom: my.temp_bedroom,
	 temp_room: my.temp_room,
	 relay_bathroom: my.relay_bathroom,
	 relay_kitchen: my.relay_kitchen,
	 relay_room: my.relay_room,
	 relay_room2: my.relay_room2,
	 relay_bedroom: my.relay_bedroom,
	};
    every((4).second(), function () {
	  app.tempBroadcast();
    });
   }
  }).start();
});

app.tempBroadcast = function (callback) {
  temper.temperature();
};


app.relay_connect_allController = function (callback) {
  if (connection_lamp_all === 0) {
    console.log(connection_lamp_all);
    connection_lamp_all = 1;
    app.sensors.relay_kitchen.digitalWrite(0);
    app.sensors.relay_bathroom.digitalWrite(0);
    app.sensors.relay_room.digitalWrite(0);
    app.sensors.relay_room2.digitalWrite(0);
    app.sensors.relay_bedroom.digitalWrite(0);
    bathroom = 1;
    kitchen = 1;
    room = 1;
    room2 = 1;
    bedroom = 1;
    controlAll_lamp = 1;

  } else {
    console.log(connection_lamp_all);
    connection_lamp_all = 0;
    app.sensors.relay_kitchen.digitalWrite(1);
    app.sensors.relay_bathroom.digitalWrite(1);
    app.sensors.relay_room.digitalWrite(1);
    app.sensors.relay_room2.digitalWrite(1);
    app.sensors.relay_bedroom.digitalWrite(1);
    bathroom = 0;
    kitchen = 0;
    room = 0;
    room2 = 0;
    bedroom = 0;
    controlAll_lamp = 0;
  }
};

app.relay_bathroomController = function (callback) {
  if (bathroom == 0) {
    bathroom = 1;
    lampOn(app.sensors.relay_bathroom);
  } else {
    bathroom = 0;
    lampOff(app.sensors.relay_bathroom);
  }

};

app.relay_kitchenContoller = function (callback) {
    if (kitchen == 0) {
      kitchen = 1;
      lampOn(app.sensors.relay_kitchen);
    } else {
      kitchen = 0;
      lampOff(app.sensors.relay_kitchen);
	}
};

app.relay_bedroomContoller = function (callback) {
	if (bedroom == 0) {
	  bedroom = 1;
	  lampOn(app.sensors.relay_bedroom);
	} else {
	  bedroom = 0;
	  lampOff(app.sensors.relay_bedroom);
	}
};

app.relay_roomController = function (callback) {
  if (room == 0) {
	room = 1;
	lampOn(app.sensors.relay_room);
	statusLamps();
  } else {
	room = 0;
	lampOff(app.sensors.relay_room);
	statusLamps();
  }

};

app.relay_room2Controller = function (callback) {
  if (room2 == 0) {
	room2 = 1;
	lampOn(app.sensors.relay_room2);
	statusLamps();
  } else {
	room2 = 0;
	lampOff(app.sensors.relay_room2);
	statusLamps();
  }
};

function statusLamps() {
  if (controlAll_lamp == 5) {
	connection_lamp_all = 1;
  } else if (controlAll_lamp < 5) {
	connection_lamp_all = 0;
  }
};

function lampOn(relay) {
  if (connection_lamp_all === 1) {
	relay.digitalWrite(0);
  } else {
	relay.digitalWrite(0);
  }
  controlAll_lamp += 1;
  statusLamps();
};

function lampOff(relay) {
  if (connection_lamp_all === 0) {
	relay.digitalWrite(1);
  } else {
	relay.digitalWrite(1);
  }
  controlAll_lamp -= 1;
  statusLamps();
};

app.control_curtain = function (callback) {
  ExeStepper.controlmotor();
};


app.listen(5040);
console.log('Im listening on port 5040');
