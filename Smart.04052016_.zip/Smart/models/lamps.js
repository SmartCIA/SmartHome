
//Variable declarations of Microcontroller lamps.
var bathroom = 0;
var connection_lamp_all = 0;
var kitchen = 0; 
var room = 0;
var room2 = 0;
var controlAll_lamp = 0;
var bedroom = 0;

exports.control_lampAll = function(all){
    connection_lamp_all = all;
  if(connection_lamp_all === 0){
    console.log(connection_lamp_all);
    connection_lamp_all = 1;
    app.sensors.relay_kitchen.digitalWrite(0);
    app.sensors.relay_bathroom.digitalWrite(0);
    app.sensors.relay_room.digitalWrite(0);
    app.sensors.relay_room2.digitalWrite(0);
    app.sensors.relay_bedroom.digitalWrite(0);
    bathroom = 1;
    kitchen = 1;
    room = 1;
    room2 = 1;
    bedroom = 1;
    controlAll_lamp = 1;
  } else {
    console.log(connection_lamp_all);
    connection_lamp_all = 0;
    app.sensors.relay_kitchen.digitalWrite(1);
    app.sensors.relay_bathroom.digitalWrite(1);
    app.sensors.relay_room.digitalWrite(1);
    app.sensors.relay_room2.digitalWrite(1);
    app.sensors.relay_bedroom.digitalWrite(1);
    bathroom = 0;
    kitchen = 0;
    room = 0;
    room2 = 0;
    bedroom = 0;
    controlAll_lamp = 0;
  }  
};

exports.room2 = function(){
  if(room2 === 0){
    room2 = 1;
    if(connection_lamp_all === 1){
      app.sensors.relay_room2.digitalWrite(0);
    } else {
      app.sensors.relay_room2.digitalWrite(0);
    }
    controlAll_lamp += 1;
    statusLamps();
  } else {
    room2 = 0;
    if(connection_lamp_all === 0){
      app.sensors.relay_room2.digitalWrite(1);
    } else{
      app.sensors.relay_room2.digitalWrite(1);
    }
    controlAll_lamp -= 1;
    statusLamps();
  }
};

exports.room = function(){
  if(room === 0){
    room = 1;
    if(connection_lamp_all === 1){
      app.sensors.relay_room.digitalWrite(0);
    } else {
      app.sensors.relay_room.digitalWrite(0);
    }
    controlAll_lamp += 1;
    statusLamps();
  } else {
    room = 0;
    if(connection_lamp_all === 0){
      app.sensors.relay_room.digitalWrite(1);
    } else {
      app.sensors.relay_room.digitalWrite(1);
    }
    controlAll_lamp -= 1;
    statusLamps();
  }
};

exports.bedroom = function(){
  if(bedroom == 0){
    bedroom = 1;
    if(connection_lamp_all === 1){
      app.sensors.relay_bedroom.digitalWrite(0);
    } else {
      app.sensors.relay_bedroom.digitalWrite(0);
    }
      controlAll_lamp += 1;
      statusLamps();
  } else {
    bedroom = 0;
    if(connection_lamp_all === 0){
      app.sensors.relay_bedroom.digitalWrite(1);
    } else {
      app.sensors.relay_bedroom.digitalWrite(1);
    }
    controlAll_lamp -= 1;
    statusLamps();
  }  
};

exports.kitchen = function(){
  if(kitchen == 0){
    kitchen = 1;
    if(connection_lamp_all === 1){
      app.sensors.relay_kitchen.digitalWrite(0);
    } else {
      app.sensors.relay_kitchen.digitalWrite(0);
    }
   controlAll_lamp += 1;
   statusLamps();
 } else {
    kitchen = 0;
    if(connection_lamp_all === 0){
      app.sensors.relay_kitchen.digitalWrite(1);
    } else {
      app.sensors.relay_kitchen.digitalWrite(1);
    }
   controlAll_lamp -= 1;
   statusLamps();
 }  
};

exports.bathroom = function(){
    if(bathroom === 0){
        bathroom = 1;
        if(connection_lamp_all === 1){
          app.sensors.relay_bathroom.digitalWrite(0);
        } else {
          app.sensors.relay_bathroom.digitalWrite(0);
        }
        statusLamps();
    } else {
      bathroom = 0;
      if(connection_lamp_all === 0){
        app.sensors.relay_bathroom.digitalWrite(1);
      } else {
        app.sensors.relay_bathroom.digitalWrite(1);
      }
      statusLamps();
    }  
};

function statusLamps(){
  if(controlAll_lamp === 5){
    connection_lamp_all = 1;
    control_lampAll(1);
  }else if(controlAll_lamp < 5){
    connection_lamp_all = 0;
    control_lampAll(0);
  }
}