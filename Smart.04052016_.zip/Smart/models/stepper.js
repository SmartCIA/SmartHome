var Stepper_lib = require('jsupm_uln200xa');
var stepper = new Stepper_lib.ULN200XA(1000, 1, 2, 3, 4);
var controlStepper = 0;

function runningStepper(direction){
    stepper.setSpeed(5); // 5 RPMs
    stepper.setDirection(direction);
    stepper.stepperSteps(1000);
}

exports.controlmotor = function(){   
  if(controlStepper === 0){
    controlStepper = 1;
    runningStepper(Stepper_lib.ULN200XA.DIR_CW);  
  }else{
    controlStepper = 0;
    runningStepper(Stepper_lib.ULN200XA.DIR_CCW);
  }
};
